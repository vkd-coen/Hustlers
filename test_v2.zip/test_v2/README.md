# Hustlers — RoboWars 2026 Sumobot

## Hardware
- STM32 Nucleo F446RE
- RPLIDAR C1 (USART3: PB10 TX / PC11 RX @ 460800 baud)
- MPU6050 IMU (I2C1: PB8 SCL / PB9 SDA)
- 4× TT DC motors + 2× L298N motor drivers
- 4× HC-SR04 ultrasonic sensors (facing DOWN for edge detection)
- JSUMO HIB03 RF receiver (433 MHz start/stop)

## Pin Assignment Summary

### Motor PWM (L298N ENA/ENB)
| Motor | PWM Pin | Timer    |
|-------|---------|----------|
| FL    | PA0     | TIM2_CH1 |
| BL    | PA3     | TIM2_CH4 |
| FR    | PA6     | TIM3_CH1 |
| BR    | PB5     | TIM3_CH2 |

### Motor Direction (L298N IN1/IN2)
| Motor | IN1  | IN2  |
|-------|------|------|
| FL    | PA1  | PA4  |
| FR    | PA7  | PA8  |
| BL    | PB6  | PB12 |
| BR    | PB0  | PB1  |

### Ultrasonic Sensors (via level shifter on ECHO pins)
| Sensor | TRIG | ECHO |
|--------|------|------|
| Front  | PA9  | PC0  |
| Back   | PB13 | PB14 |
| Left   | PB15 | PC2  |
| Right  | PC3  | PC4  |

### HIB03 RF Receiver (via level shifter)
| Signal | Pin |
|--------|-----|
| START  | PC5 |
| STOP   | PC6 |

### Comms
| Peripheral | Pins               |
|------------|--------------------|
| USART2     | PA2 TX / PA3 RX (debug → PC @ 115200) |
| USART3     | PB10 TX / PC11 RX (LiDAR @ 460800)   |
| I2C1       | PB8 SCL / PB9 SDA (IMU)               |

## Behavior FSM
STOPPED → STARTUP (wait HIB03 START) → SEARCH (spin, scan LiDAR)
  → ATTACK (face + charge opponent)
  → EDGE_ESCAPE (any US sensor detects ring edge) → resume previous state

HIB03 STOP signal preempts all states immediately.

## Wiring Notes
- HC-SR04 ECHO pins output 5V → use level shifter before STM32 GPIO
- HIB03 OUT1/OUT2 output 5V → use level shifter before STM32 GPIO
- TRIG and HIB03 power (5V) can come from STM32 Nucleo 5V pin (bench only)
- On the robot: 3S LiPo → L298N VIN (motor power)
               3S LiPo → buck 12V→5V → STM32 + sensors
- Common GND across all components is mandatory
