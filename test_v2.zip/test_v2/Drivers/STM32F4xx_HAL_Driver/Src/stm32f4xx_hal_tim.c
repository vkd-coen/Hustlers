/**
  ******************************************************************************
  * @file    stm32f4xx_hal_tim.c
  * @brief   TIM HAL module — minimal PWM implementation for STM32F4xx
  ******************************************************************************
  */

#include "stm32f4xx_hal.h"

#ifdef HAL_TIM_MODULE_ENABLED

/* ── Weak MSP callbacks — declared before use ────────────────────────── */
__weak void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *htim)   { UNUSED(htim); }
__weak void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef *htim) { UNUSED(htim); }
__weak void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef *htim)    { UNUSED(htim); }
__weak void HAL_TIM_PWM_MspDeInit(TIM_HandleTypeDef *htim)  { UNUSED(htim); }
__weak void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim)    { UNUSED(htim); }

/* ── IS_TIM_SLAVEMODE_TRIGGER_ENABLED macro ─────────────────────────── */
#ifndef IS_TIM_SLAVEMODE_TRIGGER_ENABLED
#define IS_TIM_SLAVEMODE_TRIGGER_ENABLED(MODE) \
    (((MODE) == TIM_SLAVEMODE_TRIGGER) || ((MODE) == TIM_SLAVEMODE_COMBINED_RESETTRIGGER))
#endif

/* ── Private helpers ──────────────────────────────────────────────────── */
static void TIM_Base_SetConfig(TIM_TypeDef *TIMx, TIM_Base_InitTypeDef *Structure)
{
    uint32_t tmpcr1 = TIMx->CR1;

    if (IS_TIM_COUNTER_MODE_SELECT_INSTANCE(TIMx)) {
        tmpcr1 &= ~(TIM_CR1_DIR | TIM_CR1_CMS);
        tmpcr1 |= Structure->CounterMode;
    }
    if (IS_TIM_CLOCK_DIVISION_INSTANCE(TIMx)) {
        tmpcr1 &= ~TIM_CR1_CKD;
        tmpcr1 |= (uint32_t)Structure->ClockDivision;
    }
    MODIFY_REG(tmpcr1, TIM_CR1_ARPE, Structure->AutoReloadPreload);
    TIMx->CR1  = tmpcr1;
    TIMx->ARR  = (uint32_t)Structure->Period;
    TIMx->PSC  = Structure->Prescaler;
    if (IS_TIM_REPETITION_COUNTER_INSTANCE(TIMx))
        TIMx->RCR = Structure->RepetitionCounter;
    TIMx->EGR  = TIM_EGR_UG;
}

static void TIM_OC1_SetConfig(TIM_TypeDef *TIMx, TIM_OC_InitTypeDef *OC_Config)
{
    uint32_t tmpccmrx = TIMx->CCMR1;
    uint32_t tmpccer  = TIMx->CCER;
    uint32_t tmpcr2   = TIMx->CR2;

    tmpccer  &= ~(TIM_CCER_CC1E | TIM_CCER_CC1NE);
    tmpccmrx &= ~(TIM_CCMR1_OC1M | TIM_CCMR1_CC1S);
    tmpccmrx |= OC_Config->OCMode;
    tmpccmrx |= TIM_CCMR1_OC1PE;  /* Enable preload for CCR1 */
    tmpccer  &= ~TIM_CCER_CC1P;
    tmpccer  |= OC_Config->OCPolarity;
    if (IS_TIM_CCXN_INSTANCE(TIMx, TIM_CHANNEL_1)) {
        tmpccer &= ~TIM_CCER_CC1NP;
        tmpccer |= OC_Config->OCNPolarity;
    }
    if (IS_TIM_BREAK_INSTANCE(TIMx)) {
        MODIFY_REG(tmpcr2, TIM_CR2_OIS1, OC_Config->OCIdleState);
        if (IS_TIM_CCXN_INSTANCE(TIMx, TIM_CHANNEL_1))
            MODIFY_REG(tmpcr2, TIM_CR2_OIS1N, OC_Config->OCNIdleState);
    }
    TIMx->CR2   = tmpcr2;
    TIMx->CCMR1 = tmpccmrx;
    TIMx->CCR1  = OC_Config->Pulse;
    TIMx->CCER  = tmpccer;
}

static void TIM_OC2_SetConfig(TIM_TypeDef *TIMx, TIM_OC_InitTypeDef *OC_Config)
{
    uint32_t tmpccmrx = TIMx->CCMR1;
    uint32_t tmpccer  = TIMx->CCER;
    uint32_t tmpcr2   = TIMx->CR2;

    tmpccer  &= ~(TIM_CCER_CC2E | TIM_CCER_CC2NE);
    tmpccmrx &= ~(TIM_CCMR1_OC2M | TIM_CCMR1_CC2S);
    tmpccmrx |= (OC_Config->OCMode << 8U);
    tmpccmrx |= TIM_CCMR1_OC2PE;  /* Enable preload for CCR2 */
    tmpccer  &= ~TIM_CCER_CC2P;
    tmpccer  |= (OC_Config->OCPolarity << 4U);
    if (IS_TIM_CCXN_INSTANCE(TIMx, TIM_CHANNEL_2)) {
        tmpccer &= ~TIM_CCER_CC2NP;
        tmpccer |= (OC_Config->OCNPolarity << 4U);
    }
    if (IS_TIM_BREAK_INSTANCE(TIMx)) {
        MODIFY_REG(tmpcr2, TIM_CR2_OIS2, OC_Config->OCIdleState << 2U);
        if (IS_TIM_CCXN_INSTANCE(TIMx, TIM_CHANNEL_2))
            MODIFY_REG(tmpcr2, TIM_CR2_OIS2N, OC_Config->OCNIdleState << 2U);
    }
    TIMx->CR2   = tmpcr2;
    TIMx->CCMR1 = tmpccmrx;
    TIMx->CCR2  = OC_Config->Pulse;
    TIMx->CCER  = tmpccer;
}

static void TIM_OC3_SetConfig(TIM_TypeDef *TIMx, TIM_OC_InitTypeDef *OC_Config)
{
    uint32_t tmpccmrx = TIMx->CCMR2;
    uint32_t tmpccer  = TIMx->CCER;
    uint32_t tmpcr2   = TIMx->CR2;

    tmpccer  &= ~(TIM_CCER_CC3E | TIM_CCER_CC3NE);
    tmpccmrx &= ~(TIM_CCMR2_OC3M | TIM_CCMR2_CC3S);
    tmpccmrx |= OC_Config->OCMode;
    tmpccer  &= ~TIM_CCER_CC3P;
    tmpccer  |= (OC_Config->OCPolarity << 8U);
    if (IS_TIM_CCXN_INSTANCE(TIMx, TIM_CHANNEL_3)) {
        tmpccer &= ~TIM_CCER_CC3NP;
        tmpccer |= (OC_Config->OCNPolarity << 8U);
    }
    if (IS_TIM_BREAK_INSTANCE(TIMx)) {
        MODIFY_REG(tmpcr2, TIM_CR2_OIS3, OC_Config->OCIdleState << 4U);
        if (IS_TIM_CCXN_INSTANCE(TIMx, TIM_CHANNEL_3))
            MODIFY_REG(tmpcr2, TIM_CR2_OIS3N, OC_Config->OCNIdleState << 4U);
    }
    TIMx->CR2   = tmpcr2;
    TIMx->CCMR2 = tmpccmrx;
    TIMx->CCR3  = OC_Config->Pulse;
    TIMx->CCER  = tmpccer;
}

static void TIM_OC4_SetConfig(TIM_TypeDef *TIMx, TIM_OC_InitTypeDef *OC_Config)
{
    uint32_t tmpccmrx = TIMx->CCMR2;
    uint32_t tmpccer  = TIMx->CCER;
    uint32_t tmpcr2   = TIMx->CR2;

    tmpccer  &= ~TIM_CCER_CC4E;
    tmpccmrx &= ~(TIM_CCMR2_OC4M | TIM_CCMR2_CC4S);
    tmpccmrx |= (OC_Config->OCMode << 8U);
    tmpccer  &= ~TIM_CCER_CC4P;
    tmpccer  |= (OC_Config->OCPolarity << 12U);
    if (IS_TIM_BREAK_INSTANCE(TIMx))
        MODIFY_REG(tmpcr2, TIM_CR2_OIS4, OC_Config->OCIdleState << 6U);
    TIMx->CR2   = tmpcr2;
    TIMx->CCMR2 = tmpccmrx;
    TIMx->CCR4  = OC_Config->Pulse;
    TIMx->CCER  = tmpccer;
}

/* ── Public API ───────────────────────────────────────────────────────── */
HAL_StatusTypeDef HAL_TIM_Base_Init(TIM_HandleTypeDef *htim)
{
    if (htim == NULL) return HAL_ERROR;
    htim->State = HAL_TIM_STATE_BUSY;
    HAL_TIM_Base_MspInit(htim);
    TIM_Base_SetConfig(htim->Instance, &htim->Init);
    htim->State = HAL_TIM_STATE_READY;
    return HAL_OK;
}

HAL_StatusTypeDef HAL_TIM_Base_DeInit(TIM_HandleTypeDef *htim)
{
    htim->State = HAL_TIM_STATE_BUSY;
    HAL_TIM_Base_MspDeInit(htim);
    htim->State = HAL_TIM_STATE_RESET;
    return HAL_OK;
}

HAL_StatusTypeDef HAL_TIM_PWM_Init(TIM_HandleTypeDef *htim)
{
    if (htim == NULL) return HAL_ERROR;
    htim->State = HAL_TIM_STATE_BUSY;
    HAL_TIM_PWM_MspInit(htim);
    TIM_Base_SetConfig(htim->Instance, &htim->Init);
    htim->State = HAL_TIM_STATE_READY;
    return HAL_OK;
}

HAL_StatusTypeDef HAL_TIM_PWM_DeInit(TIM_HandleTypeDef *htim)
{
    htim->State = HAL_TIM_STATE_BUSY;
    HAL_TIM_PWM_MspDeInit(htim);
    htim->State = HAL_TIM_STATE_RESET;
    return HAL_OK;
}

HAL_StatusTypeDef HAL_TIM_PWM_ConfigChannel(TIM_HandleTypeDef *htim,
                                             TIM_OC_InitTypeDef *sConfig,
                                             uint32_t Channel)
{
    switch (Channel) {
    case TIM_CHANNEL_1: TIM_OC1_SetConfig(htim->Instance, sConfig); break;
    case TIM_CHANNEL_2: TIM_OC2_SetConfig(htim->Instance, sConfig); break;
    case TIM_CHANNEL_3: TIM_OC3_SetConfig(htim->Instance, sConfig); break;
    case TIM_CHANNEL_4: TIM_OC4_SetConfig(htim->Instance, sConfig); break;
    default: return HAL_ERROR;
    }

    switch (Channel) {
    case TIM_CHANNEL_1:
        MODIFY_REG(htim->Instance->CCMR1, TIM_CCMR1_OC1FE, sConfig->OCFastMode);
        break;
    case TIM_CHANNEL_2:
        MODIFY_REG(htim->Instance->CCMR1, TIM_CCMR1_OC2FE, sConfig->OCFastMode << 8U);
        break;
    case TIM_CHANNEL_3:
        MODIFY_REG(htim->Instance->CCMR2, TIM_CCMR2_OC3FE, sConfig->OCFastMode);
        break;
    case TIM_CHANNEL_4:
        MODIFY_REG(htim->Instance->CCMR2, TIM_CCMR2_OC4FE, sConfig->OCFastMode << 8U);
        break;
    }
    return HAL_OK;
}

HAL_StatusTypeDef HAL_TIM_PWM_Start(TIM_HandleTypeDef *htim, uint32_t Channel)
{
    /* Enable the capture compare channel */
    switch (Channel) {
    case TIM_CHANNEL_1: htim->Instance->CCER |= TIM_CCER_CC1E; break;
    case TIM_CHANNEL_2: htim->Instance->CCER |= TIM_CCER_CC2E; break;
    case TIM_CHANNEL_3: htim->Instance->CCER |= TIM_CCER_CC3E; break;
    case TIM_CHANNEL_4: htim->Instance->CCER |= TIM_CCER_CC4E; break;
    default: return HAL_ERROR;
    }

    /* Enable main output for advanced timers */
    if (IS_TIM_BREAK_INSTANCE(htim->Instance))
        htim->Instance->BDTR |= TIM_BDTR_MOE;

    /* Enable the counter — always start it */
    htim->Instance->CR1 |= TIM_CR1_CEN;

    htim->State = HAL_TIM_STATE_BUSY;
    return HAL_OK;
}

HAL_StatusTypeDef HAL_TIM_PWM_Stop(TIM_HandleTypeDef *htim, uint32_t Channel)
{
    switch (Channel) {
    case TIM_CHANNEL_1: htim->Instance->CCER &= ~TIM_CCER_CC1E; break;
    case TIM_CHANNEL_2: htim->Instance->CCER &= ~TIM_CCER_CC2E; break;
    case TIM_CHANNEL_3: htim->Instance->CCER &= ~TIM_CCER_CC3E; break;
    case TIM_CHANNEL_4: htim->Instance->CCER &= ~TIM_CCER_CC4E; break;
    default: return HAL_ERROR;
    }
    htim->Instance->CR1 &= ~TIM_CR1_CEN;
    htim->State = HAL_TIM_STATE_READY;
    return HAL_OK;
}

#endif /* HAL_TIM_MODULE_ENABLED */
