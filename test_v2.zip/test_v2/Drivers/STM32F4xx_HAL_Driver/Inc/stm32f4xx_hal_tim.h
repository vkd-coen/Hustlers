/**
  ******************************************************************************
  * @file    stm32f4xx_hal_tim.h
  * @brief   Header file of TIM HAL module.
  *          Minimal version for PWM output on STM32F4xx.
  ******************************************************************************
  */
#ifndef STM32F4xx_HAL_TIM_H
#define STM32F4xx_HAL_TIM_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal_def.h"

/* ── Timer channel definitions ─────────────────────────────────────────── */
#define TIM_CHANNEL_1   0x00000000U
#define TIM_CHANNEL_2   0x00000004U
#define TIM_CHANNEL_3   0x00000008U
#define TIM_CHANNEL_4   0x0000000CU
#define TIM_CHANNEL_ALL 0x0000003CU

/* ── Counter mode ──────────────────────────────────────────────────────── */
#define TIM_COUNTERMODE_UP             0x00000000U
#define TIM_COUNTERMODE_DOWN           TIM_CR1_DIR
#define TIM_COUNTERMODE_CENTERALIGNED1 TIM_CR1_CMS_0
#define TIM_COUNTERMODE_CENTERALIGNED2 TIM_CR1_CMS_1
#define TIM_COUNTERMODE_CENTERALIGNED3 TIM_CR1_CMS

/* ── Clock division ────────────────────────────────────────────────────── */
#define TIM_CLOCKDIVISION_DIV1  0x00000000U
#define TIM_CLOCKDIVISION_DIV2  TIM_CR1_CKD_0
#define TIM_CLOCKDIVISION_DIV4  TIM_CR1_CKD_1

/* ── Auto-reload preload ───────────────────────────────────────────────── */
#define TIM_AUTORELOAD_PRELOAD_DISABLE 0x00000000U
#define TIM_AUTORELOAD_PRELOAD_ENABLE  TIM_CR1_ARPE

/* ── OC mode ───────────────────────────────────────────────────────────── */
#define TIM_OCMODE_TIMING          0x00000000U
#define TIM_OCMODE_ACTIVE          TIM_CCMR1_OC1M_0
#define TIM_OCMODE_INACTIVE        TIM_CCMR1_OC1M_1
#define TIM_OCMODE_TOGGLE          (TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_0)
#define TIM_OCMODE_PWM1            (TIM_CCMR1_OC1M_2 | TIM_CCMR1_OC1M_1)
#define TIM_OCMODE_PWM2            (TIM_CCMR1_OC1M_2 | TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_0)

/* ── OC polarity ───────────────────────────────────────────────────────── */
#define TIM_OCPOLARITY_HIGH  0x00000000U
#define TIM_OCPOLARITY_LOW   TIM_CCER_CC1P

/* ── OC fast mode ──────────────────────────────────────────────────────── */
#define TIM_OCFAST_DISABLE  0x00000000U
#define TIM_OCFAST_ENABLE   TIM_CCMR1_OC1FE

/* ── HAL TIM state ─────────────────────────────────────────────────────── */
typedef enum {
    HAL_TIM_STATE_RESET   = 0x00U,
    HAL_TIM_STATE_READY   = 0x01U,
    HAL_TIM_STATE_BUSY    = 0x02U,
    HAL_TIM_STATE_TIMEOUT = 0x03U,
    HAL_TIM_STATE_ERROR   = 0x04U
} HAL_TIM_StateTypeDef;

/* ── TIM base init structure ───────────────────────────────────────────── */
typedef struct {
    uint32_t Prescaler;
    uint32_t CounterMode;
    uint32_t Period;
    uint32_t ClockDivision;
    uint32_t RepetitionCounter;
    uint32_t AutoReloadPreload;
} TIM_Base_InitTypeDef;

/* ── TIM OC init structure ─────────────────────────────────────────────── */
typedef struct {
    uint32_t OCMode;
    uint32_t Pulse;
    uint32_t OCPolarity;
    uint32_t OCNPolarity;
    uint32_t OCFastMode;
    uint32_t OCIdleState;
    uint32_t OCNIdleState;
} TIM_OC_InitTypeDef;

/* ── TIM handle ────────────────────────────────────────────────────────── */
typedef struct {
    TIM_TypeDef              *Instance;
    TIM_Base_InitTypeDef      Init;
    HAL_TIM_StateTypeDef      State;
    uint32_t                  Channel;
    DMA_HandleTypeDef        *hdma[7];
    HAL_LockTypeDef           Lock;
} TIM_HandleTypeDef;

/* ── Macros ────────────────────────────────────────────────────────────── */
#define __HAL_TIM_SET_COMPARE(__HANDLE__, __CHANNEL__, __COMPARE__) \
    (((__CHANNEL__) == TIM_CHANNEL_1) ? ((__HANDLE__)->Instance->CCR1 = (__COMPARE__)) : \
     ((__CHANNEL__) == TIM_CHANNEL_2) ? ((__HANDLE__)->Instance->CCR2 = (__COMPARE__)) : \
     ((__CHANNEL__) == TIM_CHANNEL_3) ? ((__HANDLE__)->Instance->CCR3 = (__COMPARE__)) : \
                                        ((__HANDLE__)->Instance->CCR4 = (__COMPARE__)))

#define __HAL_TIM_GET_COMPARE(__HANDLE__, __CHANNEL__) \
    (((__CHANNEL__) == TIM_CHANNEL_1) ? ((__HANDLE__)->Instance->CCR1) : \
     ((__CHANNEL__) == TIM_CHANNEL_2) ? ((__HANDLE__)->Instance->CCR2) : \
     ((__CHANNEL__) == TIM_CHANNEL_3) ? ((__HANDLE__)->Instance->CCR3) : \
                                        ((__HANDLE__)->Instance->CCR4))

/* ── Function prototypes ───────────────────────────────────────────────── */
HAL_StatusTypeDef HAL_TIM_Base_Init(TIM_HandleTypeDef *htim);
HAL_StatusTypeDef HAL_TIM_Base_DeInit(TIM_HandleTypeDef *htim);
HAL_StatusTypeDef HAL_TIM_PWM_Init(TIM_HandleTypeDef *htim);
HAL_StatusTypeDef HAL_TIM_PWM_DeInit(TIM_HandleTypeDef *htim);
HAL_StatusTypeDef HAL_TIM_PWM_ConfigChannel(TIM_HandleTypeDef *htim,
                                             TIM_OC_InitTypeDef *sConfig,
                                             uint32_t Channel);
HAL_StatusTypeDef HAL_TIM_PWM_Start(TIM_HandleTypeDef *htim, uint32_t Channel);
HAL_StatusTypeDef HAL_TIM_PWM_Stop(TIM_HandleTypeDef *htim, uint32_t Channel);
void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

#ifdef __cplusplus
}
#endif

#endif /* STM32F4xx_HAL_TIM_H */
