/* USER CODE BEGIN Header */
/**
******************************************************************************
* @file : main.c
* @brief : Main program body — RoboWars 2026 Sumobot
******************************************************************************
*/
/* USER CODE END Header */

#include "main.h"

/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "motors.h"
#include "behavior.h"
/* USER CODE END Includes */

/* USER CODE BEGIN PD */
#define MPU6050_ADDR_68          (0x68 << 1)
#define MPU6050_ADDR_69          (0x69 << 1)
#define MPU6050_WHO_AM_I_REG     0x75
#define MPU6050_PWR_MGMT_1_REG   0x6B
#define MPU6050_ACCEL_XOUT_H_REG 0x3B
#define MPU6050_GYRO_CONFIG_REG  0x1B
#define MPU6050_ACCEL_CONFIG_REG 0x1C

#define RPLIDAR_SYNC_BYTE        0xA5
#define RPLIDAR_CMD_GET_INFO     0x50
#define RPLIDAR_CMD_STOP         0x25
#define RPLIDAR_CMD_SCAN         0x20

#define CTRL_C_BYTE              0x03

#define OPPONENT_MAX_DIST_MM     1500
#define OPPONENT_MIN_DIST_MM     100
#define OPPONENT_TIMEOUT_MS      300

#define EDGE_DANGER_CM           15
#define US_TIMEOUT_US            25000
/* USER CODE END PD */

I2C_HandleTypeDef  hi2c1;
TIM_HandleTypeDef  htim2;
TIM_HandleTypeDef  htim3;
TIM_HandleTypeDef  htim4;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
uint8_t pc_cmd        = 0;
uint8_t output_paused = 0;

uint8_t           who_am_i  = 0;
uint16_t          mpu_addr  = MPU6050_ADDR_68;
HAL_StatusTypeDef mpu_status;

volatile int16_t accel_x_raw, accel_y_raw, accel_z_raw;
volatile int16_t temp_raw;
volatile int16_t gyro_x_raw, gyro_y_raw, gyro_z_raw;
volatile int32_t accel_x_mg, accel_y_mg, accel_z_mg;
volatile int32_t gyro_x_dps_x100, gyro_y_dps_x100, gyro_z_dps_x100;
volatile int32_t temp_c_x100;

uint8_t imu_data[14];
char    uart_buf[220];

uint8_t  lidar_info_rx[27];
uint8_t  lidar_desc[7];
uint8_t  lidar_node[5];
char     debug_msg[220];

volatile uint8_t  lidar_scan_running  = 0;
volatile uint32_t lidar_valid_samples = 0;
volatile uint32_t lidar_print_counter = 0;

volatile uint8_t  opponent_detected     = 0;
volatile float    opponent_angle        = 0.0f;
volatile float    opponent_distance     = 99999.0f;
volatile uint32_t opponent_last_seen_ms = 0;

static float scan_min_dist  = 99999.0f;
static float scan_min_angle = 0.0f;

volatile uint8_t  edge_front = 0;
volatile uint8_t  edge_back  = 0;

volatile uint32_t us_dist_front_cm = 0;
volatile uint32_t us_dist_back_cm  = 0;

uint32_t last_imu_read    = 0;
uint32_t last_imu_print   = 0;
uint32_t last_led_toggle  = 0;
uint32_t last_behavior    = 0;
uint32_t last_opp_refresh = 0;
uint32_t last_us_read     = 0;
/* USER CODE END PV */

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);

/* USER CODE BEGIN PFP */
void    Debug_Print(char *msg);
void    Check_PC_Command(void);
uint8_t           MPU6050_Detect(void);
void              MPU6050_Init(void);
HAL_StatusTypeDef MPU6050_Read_All(void);
void              MPU6050_Recover_I2C(void);
void              UART_Print_IMU(void);
void    RPLIDAR_Stop(void);
void    RPLIDAR_Clear_UART_Buffer(void);
void    RPLIDAR_GetInfo_Test(void);
uint8_t RPLIDAR_Start_Scan(void);
uint8_t RPLIDAR_Read_Valid_Node(uint8_t *node, uint32_t timeout_ms);
void    RPLIDAR_Process_Node(uint8_t *node);
uint32_t US_ReadDistance_cm(GPIO_TypeDef *trig_port, uint16_t trig_pin,
                             GPIO_TypeDef *echo_port, uint16_t echo_pin);
void     US_ReadAll(void);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

void Debug_Print(char *msg)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)msg, strlen(msg), 1000);
}

void Check_PC_Command(void)
{
    if (HAL_UART_Receive(&huart2, &pc_cmd, 1, 0) == HAL_OK)
    {
        if (pc_cmd == CTRL_C_BYTE)
        {
            if (!output_paused) {
                output_paused = 1;
                Debug_Print("\r\n--- CTRL+C: pausing ---\r\n");
                RPLIDAR_Stop();
                lidar_scan_running = 0;
                Behavior_Stop();
                Motors_Stop();
                Debug_Print("--- PAUSED. Ctrl+C to resume. ---\r\n");
            } else {
                output_paused = 0;
                Debug_Print("\r\n--- CTRL+C: resuming ---\r\n");
                if (!RPLIDAR_Start_Scan())
                    Debug_Print("RPLIDAR restart failed.\r\n");
                Behavior_Start();
                Debug_Print("--- RESUMED. ---\r\n");
            }
        }
    }
}

uint8_t MPU6050_Detect(void)
{
    who_am_i   = 0;
    mpu_status = HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR_68, MPU6050_WHO_AM_I_REG,
                                  I2C_MEMADD_SIZE_8BIT, &who_am_i, 1, 100);
    if (mpu_status == HAL_OK && who_am_i == 0x68) { mpu_addr = MPU6050_ADDR_68; return 1; }
    who_am_i   = 0;
    mpu_status = HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR_69, MPU6050_WHO_AM_I_REG,
                                  I2C_MEMADD_SIZE_8BIT, &who_am_i, 1, 100);
    if (mpu_status == HAL_OK && who_am_i == 0x68) { mpu_addr = MPU6050_ADDR_69; return 1; }
    return 0;
}

void MPU6050_Init(void)
{
    uint8_t data = 0x00;
    HAL_I2C_Mem_Write(&hi2c1, mpu_addr, MPU6050_PWR_MGMT_1_REG,
                      I2C_MEMADD_SIZE_8BIT, &data, 1, 100);
    HAL_Delay(100);
    HAL_I2C_Mem_Write(&hi2c1, mpu_addr, MPU6050_GYRO_CONFIG_REG,
                      I2C_MEMADD_SIZE_8BIT, &data, 1, 100);
    HAL_I2C_Mem_Write(&hi2c1, mpu_addr, MPU6050_ACCEL_CONFIG_REG,
                      I2C_MEMADD_SIZE_8BIT, &data, 1, 100);
}

HAL_StatusTypeDef MPU6050_Read_All(void)
{
    HAL_StatusTypeDef s = HAL_I2C_Mem_Read(&hi2c1, mpu_addr,
        MPU6050_ACCEL_XOUT_H_REG, I2C_MEMADD_SIZE_8BIT, imu_data, 14, 100);
    if (s != HAL_OK) return s;
    accel_x_raw = (int16_t)((imu_data[0]  << 8) | imu_data[1]);
    accel_y_raw = (int16_t)((imu_data[2]  << 8) | imu_data[3]);
    accel_z_raw = (int16_t)((imu_data[4]  << 8) | imu_data[5]);
    temp_raw    = (int16_t)((imu_data[6]  << 8) | imu_data[7]);
    gyro_x_raw  = (int16_t)((imu_data[8]  << 8) | imu_data[9]);
    gyro_y_raw  = (int16_t)((imu_data[10] << 8) | imu_data[11]);
    gyro_z_raw  = (int16_t)((imu_data[12] << 8) | imu_data[13]);
    accel_x_mg       = ((int32_t)accel_x_raw * 1000) / 16384;
    accel_y_mg       = ((int32_t)accel_y_raw * 1000) / 16384;
    accel_z_mg       = ((int32_t)accel_z_raw * 1000) / 16384;
    gyro_x_dps_x100  = ((int32_t)gyro_x_raw  * 100)  / 131;
    gyro_y_dps_x100  = ((int32_t)gyro_y_raw  * 100)  / 131;
    gyro_z_dps_x100  = ((int32_t)gyro_z_raw  * 100)  / 131;
    temp_c_x100      = (((int32_t)temp_raw    * 100)  / 340) + 3653;
    return HAL_OK;
}

void MPU6050_Recover_I2C(void)
{
    Debug_Print("MPU6050 I2C recovery...\r\n");
    HAL_I2C_DeInit(&hi2c1);
    HAL_Delay(50);
    MX_I2C1_Init();
    HAL_Delay(100);
    if (MPU6050_Detect()) MPU6050_Init();
}

void UART_Print_IMU(void)
{
    int len = snprintf(uart_buf, sizeof(uart_buf),
        "IMU | ACC mg: X=%ld Y=%ld Z=%ld | GYRO dps: X=%ld.%02ld Y=%ld.%02ld Z=%ld.%02ld | TEMP=%ld.%02ld C\r\n",
        accel_x_mg, accel_y_mg, accel_z_mg,
        gyro_x_dps_x100/100, labs(gyro_x_dps_x100%100),
        gyro_y_dps_x100/100, labs(gyro_y_dps_x100%100),
        gyro_z_dps_x100/100, labs(gyro_z_dps_x100%100),
        temp_c_x100/100, labs(temp_c_x100%100));
    if (len > 0) HAL_UART_Transmit(&huart2, (uint8_t *)uart_buf, len, 100);
}

void RPLIDAR_Stop(void)
{
    uint8_t cmd[2] = {RPLIDAR_SYNC_BYTE, RPLIDAR_CMD_STOP};
    HAL_UART_Transmit(&huart3, cmd, 2, 100);
    HAL_Delay(100);
}

void RPLIDAR_Clear_UART_Buffer(void)
{
    uint8_t dump;
    while (HAL_UART_Receive(&huart3, &dump, 1, 5) == HAL_OK) {}
}

void RPLIDAR_GetInfo_Test(void)
{
    uint8_t cmd[2] = {RPLIDAR_SYNC_BYTE, RPLIDAR_CMD_GET_INFO};
    memset(lidar_info_rx, 0, sizeof(lidar_info_rx));
    RPLIDAR_Stop();
    RPLIDAR_Clear_UART_Buffer();
    HAL_UART_Transmit(&huart3, cmd, 2, 100);
    HAL_StatusTypeDef s = HAL_UART_Receive(&huart3, lidar_info_rx, 27, 1000);
    if (s == HAL_OK && lidar_info_rx[0] == 0xA5 && lidar_info_rx[1] == 0x5A)
        Debug_Print("RPLIDAR GET_INFO valid\r\n");
    else
        Debug_Print("RPLIDAR GET_INFO failed\r\n");
}

uint8_t RPLIDAR_Start_Scan(void)
{
    uint8_t cmd[2] = {RPLIDAR_SYNC_BYTE, RPLIDAR_CMD_SCAN};
    RPLIDAR_Stop();
    RPLIDAR_Clear_UART_Buffer();
    HAL_UART_Transmit(&huart3, cmd, 2, 100);
    memset(lidar_desc, 0, sizeof(lidar_desc));
    HAL_StatusTypeDef s = HAL_UART_Receive(&huart3, lidar_desc, 7, 1000);
    if (s != HAL_OK || lidar_desc[0] != 0xA5 || lidar_desc[1] != 0x5A) {
        lidar_scan_running = 0;
        return 0;
    }
    Debug_Print("RPLIDAR scan started\r\n");
    lidar_scan_running  = 1;
    lidar_valid_samples = 0;
    lidar_print_counter = 0;
    scan_min_dist       = 99999.0f;
    return 1;
}

uint8_t RPLIDAR_Read_Valid_Node(uint8_t *node, uint32_t timeout_ms)
{
    uint32_t t0 = HAL_GetTick();
    uint8_t  b  = 0;
    while ((HAL_GetTick() - t0) < timeout_ms) {
        if (HAL_UART_Receive(&huart3, &b, 1, 2) == HAL_OK) {
            node[0]=node[1]; node[1]=node[2];
            node[2]=node[3]; node[3]=node[4]; node[4]=b;
            if (((node[0]&0x01) != ((node[0]>>1)&0x01)) && ((node[1]&0x01)==1))
                return 1;
        }
    }
    return 0;
}

void RPLIDAR_Process_Node(uint8_t *node)
{
    uint8_t  quality     = node[0] >> 2;
    uint16_t angle_q6    = ((uint16_t)node[1] | ((uint16_t)node[2] << 8)) >> 1;
    uint16_t distance_q2 = ((uint16_t)node[3] | ((uint16_t)node[4] << 8));
    if (distance_q2 == 0) return;
    float angle_deg   = (float)angle_q6   / 64.0f;
    float distance_mm = (float)distance_q2 / 4.0f;
    if (angle_deg >= 360.0f) return;
    if (distance_mm < OPPONENT_MIN_DIST_MM || distance_mm > 6000.0f) return;
    if (quality < 10) return;
    if (distance_mm < scan_min_dist && distance_mm < OPPONENT_MAX_DIST_MM) {
        scan_min_dist  = distance_mm;
        scan_min_angle = angle_deg;
    }
    lidar_print_counter++;
    if (lidar_print_counter >= 20) {
        lidar_print_counter = 0;
        uint16_t a_int  = (uint16_t)angle_deg;
        uint16_t a_frac = (uint16_t)((angle_deg  - a_int)  * 100);
        uint16_t d_int  = (uint16_t)distance_mm;
        uint16_t d_frac = (uint16_t)((distance_mm - d_int) * 100);
        snprintf(debug_msg, sizeof(debug_msg),
            "LIDAR | Sample=%lu | Angle=%u.%02u deg | Distance=%u.%02u mm | Quality=%u\r\n",
            lidar_valid_samples, a_int, a_frac, d_int, d_frac, quality);
        Debug_Print(debug_msg);
    }
}

static inline uint32_t dwt_us(void)
{
    return DWT->CYCCNT / (SystemCoreClock / 1000000U);
}

uint32_t US_ReadDistance_cm(GPIO_TypeDef *trig_port, uint16_t trig_pin,
                             GPIO_TypeDef *echo_port, uint16_t echo_pin)
{
    HAL_GPIO_WritePin(trig_port, trig_pin, GPIO_PIN_RESET);
    uint32_t t = dwt_us(); while ((dwt_us()-t) < 2) {}
    HAL_GPIO_WritePin(trig_port, trig_pin, GPIO_PIN_SET);
    t = dwt_us(); while ((dwt_us()-t) < 10) {}
    HAL_GPIO_WritePin(trig_port, trig_pin, GPIO_PIN_RESET);
    uint32_t t0 = dwt_us();
    while (HAL_GPIO_ReadPin(echo_port, echo_pin) == GPIO_PIN_RESET) {
        if ((dwt_us()-t0) > US_TIMEOUT_US) return 0;
    }
    uint32_t echo_start = dwt_us();
    while (HAL_GPIO_ReadPin(echo_port, echo_pin) == GPIO_PIN_SET) {
        if ((dwt_us()-echo_start) > US_TIMEOUT_US) return 0;
    }
    return (dwt_us()-echo_start) * 34 / 2000;
}

void US_ReadAll(void)
{
    us_dist_front_cm = US_ReadDistance_cm(
        US_FRONT_TRIG_GPIO_Port, US_FRONT_TRIG_Pin,
        US_FRONT_ECHO_GPIO_Port, US_FRONT_ECHO_Pin);
    us_dist_back_cm  = US_ReadDistance_cm(
        US_BACK_TRIG_GPIO_Port,  US_BACK_TRIG_Pin,
        US_BACK_ECHO_GPIO_Port,  US_BACK_ECHO_Pin);
    edge_front = (us_dist_front_cm == 0 || us_dist_front_cm > EDGE_DANGER_CM) ? 1 : 0;
    edge_back  = (us_dist_back_cm  == 0 || us_dist_back_cm  > EDGE_DANGER_CM) ? 1 : 0;
}

/* USER CODE END 0 */

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_I2C1_Init();
    MX_USART2_UART_Init();
    MX_USART3_UART_Init();
    MX_TIM2_Init();
    MX_TIM3_Init();
    MX_TIM4_Init();

    /* USER CODE BEGIN 2 */
    HAL_Delay(500);
    Debug_Print("\r\nSTM32 started\r\n");
    Debug_Print("Ctrl+C in PuTTY to pause/resume.\r\n");

    Motors_Init();
    Debug_Print("Motors initialized\r\n");

    if (MPU6050_Detect()) {
        MPU6050_Init();
        Debug_Print("MPU6050 detected and initialized\r\n");
    } else {
        Debug_Print("MPU6050 NOT detected\r\n");
    }

    RPLIDAR_GetInfo_Test();
    if (!RPLIDAR_Start_Scan()) Debug_Print("RPLIDAR scan did not start.\r\n");

    Behavior_Start();
    /* USER CODE END 2 */

    while (1)
    {
        Check_PC_Command();

        if (output_paused) {
            if (HAL_GetTick() - last_led_toggle >= 1000) {
                last_led_toggle = HAL_GetTick();
                HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
            }
            HAL_Delay(10);
            continue;
        }

        /* LiDAR */
        if (lidar_scan_running) {
            if (RPLIDAR_Read_Valid_Node(lidar_node, 10)) {
                lidar_valid_samples++;
                RPLIDAR_Process_Node(lidar_node);
            }
        }

        /* ── DEBUG: print LiDAR + US status every second ── */
        static uint32_t last_debug = 0;
        if (HAL_GetTick() - last_debug >= 1000) {
            last_debug = HAL_GetTick();
            snprintf(debug_msg, sizeof(debug_msg),
                "LIDAR running=%d samples=%lu | US F=%lucm B=%lucm | edge F=%d B=%d\r\n",
                lidar_scan_running, lidar_valid_samples,
                us_dist_front_cm, us_dist_back_cm,
                edge_front, edge_back);
            Debug_Print(debug_msg);
        }

        /* Opponent refresh every 100ms */
        if (HAL_GetTick() - last_opp_refresh >= 100) {
            last_opp_refresh = HAL_GetTick();
            if (scan_min_dist < OPPONENT_MAX_DIST_MM) {
                opponent_detected     = 1;
                opponent_distance     = scan_min_dist;
                opponent_angle        = scan_min_angle;
                opponent_last_seen_ms = HAL_GetTick();
            } else if (HAL_GetTick() - opponent_last_seen_ms > OPPONENT_TIMEOUT_MS) {
                opponent_detected = 0;
            }
            scan_min_dist = 99999.0f;
        }

        /* US read every 50ms */
        /* TEMPORARILY DISABLED — sensors not wired yet */
        /* if (HAL_GetTick() - last_us_read >= 50) {   */
        /*     last_us_read = HAL_GetTick();            */
        /*     US_ReadAll();                            */
        /* }                                            */
        edge_front = 0;
        edge_back  = 0;

        /* Behavior FSM every 50ms */
        if (HAL_GetTick() - last_behavior >= 50) {
            last_behavior = HAL_GetTick();
            Behavior_Tick();
        }

        /* IMU read every 100ms */
        if (HAL_GetTick() - last_imu_read >= 100) {
            last_imu_read = HAL_GetTick();
            if (mpu_status == HAL_OK && who_am_i == 0x68)
                if (MPU6050_Read_All() != HAL_OK) MPU6050_Recover_I2C();
        }

        /* IMU print every second */
        if (HAL_GetTick() - last_imu_print >= 1000) {
            last_imu_print = HAL_GetTick();
            if (mpu_status == HAL_OK && who_am_i == 0x68) UART_Print_IMU();
        }

        /* LED heartbeat */
        if (HAL_GetTick() - last_led_toggle >= 500) {
            last_led_toggle = HAL_GetTick();
            HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
        }
    }
}

void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);
    RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState            = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource       = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM            = 16;
    RCC_OscInitStruct.PLL.PLLN            = 336;
    RCC_OscInitStruct.PLL.PLLP            = RCC_PLLP_DIV4;
    RCC_OscInitStruct.PLL.PLLQ            = 2;
    RCC_OscInitStruct.PLL.PLLR            = 2;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();
    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                                     |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) Error_Handler();
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0;
    DWT->CTRL  |= DWT_CTRL_CYCCNTENA_Msk;
}

static void MX_I2C1_Init(void)
{
    hi2c1.Instance             = I2C1;
    hi2c1.Init.ClockSpeed      = 100000;
    hi2c1.Init.DutyCycle       = I2C_DUTYCYCLE_2;
    hi2c1.Init.OwnAddress1     = 0;
    hi2c1.Init.AddressingMode  = I2C_ADDRESSINGMODE_7BIT;
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c1.Init.OwnAddress2     = 0;
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c1.Init.NoStretchMode   = I2C_NOSTRETCH_DISABLE;
    if (HAL_I2C_Init(&hi2c1) != HAL_OK) Error_Handler();
}

static void MX_USART2_UART_Init(void)
{
    huart2.Instance          = USART2;
    huart2.Init.BaudRate     = 115200;
    huart2.Init.WordLength   = UART_WORDLENGTH_8B;
    huart2.Init.StopBits     = UART_STOPBITS_1;
    huart2.Init.Parity       = UART_PARITY_NONE;
    huart2.Init.Mode         = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart2) != HAL_OK) Error_Handler();
}

static void MX_USART3_UART_Init(void)
{
    huart3.Instance          = USART3;
    huart3.Init.BaudRate     = 460800;
    huart3.Init.WordLength   = UART_WORDLENGTH_8B;
    huart3.Init.StopBits     = UART_STOPBITS_1;
    huart3.Init.Parity       = UART_PARITY_NONE;
    huart3.Init.Mode         = UART_MODE_TX_RX;
    huart3.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart3.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart3) != HAL_OK) Error_Handler();
}

static void MX_TIM2_Init(void)
{
    __HAL_RCC_TIM2_CLK_ENABLE();
    htim2.Instance               = TIM2;
    htim2.Init.Prescaler         = 83;
    htim2.Init.CounterMode       = TIM_COUNTERMODE_UP;
    htim2.Init.Period            = 999;
    htim2.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
    htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
    if (HAL_TIM_PWM_Init(&htim2) != HAL_OK) Error_Handler();
    TIM_OC_InitTypeDef oc = {0};
    oc.OCMode=TIM_OCMODE_PWM1; oc.Pulse=0;
    oc.OCPolarity=TIM_OCPOLARITY_HIGH; oc.OCFastMode=TIM_OCFAST_DISABLE;
    if (HAL_TIM_PWM_ConfigChannel(&htim2, &oc, TIM_CHANNEL_1) != HAL_OK) Error_Handler();
}

static void MX_TIM3_Init(void)
{
    __HAL_RCC_TIM3_CLK_ENABLE();
    htim3.Instance               = TIM3;
    htim3.Init.Prescaler         = 83;
    htim3.Init.CounterMode       = TIM_COUNTERMODE_UP;
    htim3.Init.Period            = 999;
    htim3.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
    htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
    if (HAL_TIM_PWM_Init(&htim3) != HAL_OK) Error_Handler();
    TIM_OC_InitTypeDef oc = {0};
    oc.OCMode=TIM_OCMODE_PWM1; oc.Pulse=0;
    oc.OCPolarity=TIM_OCPOLARITY_HIGH; oc.OCFastMode=TIM_OCFAST_DISABLE;
    if (HAL_TIM_PWM_ConfigChannel(&htim3, &oc, TIM_CHANNEL_1) != HAL_OK) Error_Handler();
    if (HAL_TIM_PWM_ConfigChannel(&htim3, &oc, TIM_CHANNEL_2) != HAL_OK) Error_Handler();
}

static void MX_TIM4_Init(void)
{
    __HAL_RCC_TIM4_CLK_ENABLE();
    htim4.Instance               = TIM4;
    htim4.Init.Prescaler         = 83;
    htim4.Init.CounterMode       = TIM_COUNTERMODE_UP;
    htim4.Init.Period            = 999;
    htim4.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
    htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
    if (HAL_TIM_PWM_Init(&htim4) != HAL_OK) Error_Handler();
    TIM_OC_InitTypeDef oc = {0};
    oc.OCMode=TIM_OCMODE_PWM1; oc.Pulse=0;
    oc.OCPolarity=TIM_OCPOLARITY_HIGH; oc.OCFastMode=TIM_OCFAST_DISABLE;
    if (HAL_TIM_PWM_ConfigChannel(&htim4, &oc, TIM_CHANNEL_1) != HAL_OK) Error_Handler();
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef g = {0};
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOH_CLK_ENABLE();

    HAL_GPIO_WritePin(LD2_GPIO_Port,      LD2_Pin,      GPIO_PIN_RESET);
    HAL_GPIO_WritePin(M_FL_IN1_GPIO_Port, M_FL_IN1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(M_FL_IN2_GPIO_Port, M_FL_IN2_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(M_FR_IN1_GPIO_Port, M_FR_IN1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(M_FR_IN2_GPIO_Port, M_FR_IN2_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(M_BL_IN1_GPIO_Port, M_BL_IN1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(M_BL_IN2_GPIO_Port, M_BL_IN2_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(M_BR_IN1_GPIO_Port, M_BR_IN1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(M_BR_IN2_GPIO_Port, M_BR_IN2_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(US_FRONT_TRIG_GPIO_Port, US_FRONT_TRIG_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(US_BACK_TRIG_GPIO_Port,  US_BACK_TRIG_Pin,  GPIO_PIN_RESET);

    g.Pin=B1_Pin; g.Mode=GPIO_MODE_IT_FALLING; g.Pull=GPIO_NOPULL;
    HAL_GPIO_Init(B1_GPIO_Port, &g);

    g.Pin=LD2_Pin; g.Mode=GPIO_MODE_OUTPUT_PP; g.Pull=GPIO_NOPULL; g.Speed=GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LD2_GPIO_Port, &g);

    g.Mode=GPIO_MODE_AF_PP; g.Pull=GPIO_NOPULL; g.Speed=GPIO_SPEED_FREQ_HIGH;
    g.Alternate=GPIO_AF1_TIM2; g.Pin=GPIO_PIN_0; HAL_GPIO_Init(GPIOA, &g);
    g.Alternate=GPIO_AF2_TIM3; g.Pin=GPIO_PIN_6; HAL_GPIO_Init(GPIOA, &g);
    g.Alternate=GPIO_AF2_TIM3; g.Pin=GPIO_PIN_5; HAL_GPIO_Init(GPIOB, &g);
    g.Alternate=GPIO_AF2_TIM4; g.Pin=GPIO_PIN_6; HAL_GPIO_Init(GPIOB, &g);

    g.Mode=GPIO_MODE_OUTPUT_PP; g.Pull=GPIO_NOPULL; g.Speed=GPIO_SPEED_FREQ_LOW; g.Alternate=0;
    g.Pin=M_FL_IN1_Pin|M_FL_IN2_Pin|M_FR_IN1_Pin|M_FR_IN2_Pin; HAL_GPIO_Init(GPIOA, &g);
    g.Pin=M_BL_IN1_Pin|M_BL_IN2_Pin|M_BR_IN1_Pin|M_BR_IN2_Pin; HAL_GPIO_Init(GPIOB, &g);

    g.Speed=GPIO_SPEED_FREQ_HIGH;
    g.Pin=US_FRONT_TRIG_Pin; HAL_GPIO_Init(US_FRONT_TRIG_GPIO_Port, &g);
    g.Pin=US_BACK_TRIG_Pin;  HAL_GPIO_Init(US_BACK_TRIG_GPIO_Port,  &g);

    g.Mode=GPIO_MODE_INPUT; g.Pull=GPIO_NOPULL;
    g.Pin=US_FRONT_ECHO_Pin; HAL_GPIO_Init(US_FRONT_ECHO_GPIO_Port, &g);
    g.Pin=US_BACK_ECHO_Pin;  HAL_GPIO_Init(US_BACK_ECHO_GPIO_Port,  &g);

    g.Pull=GPIO_PULLDOWN;
    g.Pin=HIB03_START_Pin | HIB03_STOP_Pin;
    HAL_GPIO_Init(GPIOC, &g);

    g.Mode=GPIO_MODE_AF_PP; g.Pull=GPIO_NOPULL; g.Speed=GPIO_SPEED_FREQ_VERY_HIGH;
    g.Alternate=GPIO_AF7_USART3; g.Pin=GPIO_PIN_10; HAL_GPIO_Init(GPIOB, &g);
    g.Pin=GPIO_PIN_11; HAL_GPIO_Init(GPIOC, &g);

    g.Alternate=GPIO_AF7_USART2; g.Pin=GPIO_PIN_2|GPIO_PIN_3; HAL_GPIO_Init(GPIOA, &g);

    g.Mode=GPIO_MODE_AF_OD; g.Pull=GPIO_NOPULL; g.Speed=GPIO_SPEED_FREQ_LOW;
    g.Alternate=GPIO_AF4_I2C1; g.Pin=GPIO_PIN_8|GPIO_PIN_9; HAL_GPIO_Init(GPIOB, &g);
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

void Error_Handler(void)
{
    __disable_irq();
    while (1) { HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin); HAL_Delay(100); }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line) {}
#endif
