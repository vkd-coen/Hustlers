/*
 * behavior.c
 * RoboWars sumobot behavior
 *
 * JSUMO / HIB03 remote mapping:
 *   Button 1 = READY / pair on JSUMO module itself
 *   Button 2 = START output -> PC5
 *   Button 3 = STOP  output -> PC6
 *
 * Robot behavior:
 *   - On boot: motors stopped, wait for START
 *   - START/PC5 high for debounce time: enter SEARCH
 *   - STOP/PC6 high at any time: stop motors and return to STARTUP
 */

#include "behavior.h"
#include "motors.h"
#include "main.h"
#include <math.h>
#include <string.h>
#include <stdio.h>

extern volatile uint8_t  opponent_detected;
extern volatile float    opponent_angle;
extern volatile float    opponent_distance;
extern volatile uint8_t  edge_front;
extern volatile uint8_t  edge_back;
extern volatile uint32_t us_dist_front_cm;
extern volatile uint32_t us_dist_back_cm;
extern UART_HandleTypeDef huart2;

#define JSUMO_DEBOUNCE_MS    50
#define EDGE_APPROACH_CM     10
#define APPROACH_SPEED       25
#define SPIN_SPEED           40
#define CHARGE_SPEED         100
#define ALIGN_SPEED          30
#define ESCAPE_REVERSE_MS    300
#define ESCAPE_SPIN_MS       500
#define ALIGN_THRESHOLD_DEG  15.0f

static BehaviorState state            = BEHAVIOR_STOPPED;
static BehaviorState pre_escape_state = BEHAVIOR_SEARCH;
static uint32_t      state_ms         = 0;
static uint32_t      start_high_ms    = 0;
static uint32_t      stop_high_ms     = 0;
static uint8_t       escape_side      = 0;
static uint32_t      last_dbg_ms      = 0;
static char          dbg[180];

static void enter(BehaviorState s)
{
    state = s;
    state_ms = HAL_GetTick();
}

static uint8_t jsumo_start(void)
{
    return HAL_GPIO_ReadPin(HIB03_START_GPIO_Port, HIB03_START_Pin) == GPIO_PIN_SET;
}

static uint8_t jsumo_stop(void)
{
    return HAL_GPIO_ReadPin(HIB03_STOP_GPIO_Port, HIB03_STOP_Pin) == GPIO_PIN_SET;
}

static uint8_t any_edge(void)
{
    return edge_front || edge_back;
}

static void cache_escape_side(void)
{
    escape_side = edge_front ? 0 : 1;
}

static uint32_t escape_side_dist(void)
{
    return (escape_side == 0) ? us_dist_front_cm : us_dist_back_cm;
}

static void print_waiting_debug(void)
{
    uint32_t now = HAL_GetTick();

    if (now - last_dbg_ms < 250) {
        return;
    }

    last_dbg_ms = now;

    snprintf(dbg, sizeof(dbg),
             "JSUMO WAIT | START_PC5=%d STOP_PC6=%d | state=%d | t=%lu\r\n",
             jsumo_start(),
             jsumo_stop(),
             (int)state,
             now - state_ms);

    HAL_UART_Transmit(&huart2, (uint8_t *)dbg, strlen(dbg), 50);
}

void Behavior_Start(void)
{
    start_high_ms = 0;
    stop_high_ms  = 0;
    last_dbg_ms   = 0;
    enter(BEHAVIOR_STARTUP);
}

void Behavior_Stop(void)
{
    enter(BEHAVIOR_STOPPED);
    Motors_Stop();
}

void Behavior_Tick(void)
{
    uint32_t now = HAL_GetTick();

    /* STOP has priority in every state. Button 3 should drive PC6 HIGH. */
    if (jsumo_stop()) {
        if (stop_high_ms == 0) {
            stop_high_ms = now;
        }

        if (now - stop_high_ms >= JSUMO_DEBOUNCE_MS) {
            Motors_Stop();
            start_high_ms = 0;

            if (state != BEHAVIOR_STARTUP) {
                HAL_UART_Transmit(&huart2,
                                  (uint8_t *)"JSUMO STOP -> STARTUP\r\n",
                                  23,
                                  50);
            }

            enter(BEHAVIOR_STARTUP);
            return;
        }
    } else {
        stop_high_ms = 0;
    }

    switch (state) {

    case BEHAVIOR_STOPPED:
        Motors_Stop();
        break;

    case BEHAVIOR_STARTUP:
        Motors_Stop();
        print_waiting_debug();

        /* START: button 2 should drive PC5 HIGH. */
        if (jsumo_start()) {
            if (start_high_ms == 0) {
                start_high_ms = now;
            }

            if (now - start_high_ms >= JSUMO_DEBOUNCE_MS) {
                HAL_UART_Transmit(&huart2,
                                  (uint8_t *)"JSUMO START -> SEARCH\r\n",
                                  23,
                                  50);
                start_high_ms = 0;
                enter(BEHAVIOR_SEARCH);
            }
        } else {
            start_high_ms = 0;
        }
        break;

    case BEHAVIOR_SEARCH:
        if (any_edge()) {
            pre_escape_state = BEHAVIOR_SEARCH;
            cache_escape_side();
            enter(BEHAVIOR_EDGE_ESCAPE);
            break;
        }

        Motors_Drive(0, SPIN_SPEED);

        if (opponent_detected && opponent_distance < 1500.0f) {
            enter(BEHAVIOR_ATTACK);
        }
        break;

    case BEHAVIOR_ATTACK:
        if (any_edge()) {
            pre_escape_state = BEHAVIOR_ATTACK;
            cache_escape_side();
            enter(BEHAVIOR_EDGE_ESCAPE);
            break;
        }

        if (!opponent_detected) {
            enter(BEHAVIOR_SEARCH);
            break;
        }

        {
            float a = opponent_angle;

            if (a > 180.0f) {
                a -= 360.0f;
            }

            int16_t turn = (int16_t)(a * 0.6f);

            if (turn > 60) {
                turn = 60;
            }
            if (turn < -60) {
                turn = -60;
            }

            int8_t linear = (fabsf(a) < ALIGN_THRESHOLD_DEG)
                            ? CHARGE_SPEED
                            : ALIGN_SPEED;

            Motors_Drive(linear, (int8_t)turn);
        }
        break;

    case BEHAVIOR_EDGE_ESCAPE: {
        uint32_t elapsed = now - state_ms;
        uint32_t dist    = escape_side_dist();

        if (elapsed < ESCAPE_REVERSE_MS) {
            if (dist == 0 || dist > EDGE_APPROACH_CM) {
                Motors_Stop();
            } else if (escape_side == 0) {
                Motors_Drive(APPROACH_SPEED, 0);
            } else {
                Motors_Drive(-APPROACH_SPEED, 0);
            }
        } else if (elapsed < ESCAPE_REVERSE_MS + ESCAPE_SPIN_MS) {
            Motors_Drive(0, 100);
        } else {
            enter(pre_escape_state);
        }
        break;
    }

    default:
        Motors_Stop();
        enter(BEHAVIOR_STARTUP);
        break;
    }
}
