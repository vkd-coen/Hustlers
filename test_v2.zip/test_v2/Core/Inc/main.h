/* USER CODE BEGIN Header */
/**
******************************************************************************
* @file           : main.h
* @brief          : Header for main.c — pin definitions for RoboWars sumobot
******************************************************************************
*/
/* USER CODE END Header */

#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal.h"

/* ── User button & LED ────────────────────────────────────────────────────── */
#define B1_Pin              GPIO_PIN_13
#define B1_GPIO_Port        GPIOC
#define LD2_Pin             GPIO_PIN_5
#define LD2_GPIO_Port       GPIOA

/* ── Motor PWM pins (alternate function, configured in MX_TIMx_Init) ────────
   FL  PA0  TIM2_CH1
   FR  PA6  TIM3_CH1
   BR  PB5  TIM3_CH2
   BL  PB6  TIM4_CH1  ← PA3 conflict with USART2_RX, moved here             */

/* ── Motor direction pins (GPIO output) ─────────────────────────────────── */
#define M_FL_IN1_Pin        GPIO_PIN_1
#define M_FL_IN1_GPIO_Port  GPIOA
#define M_FL_IN2_Pin        GPIO_PIN_4
#define M_FL_IN2_GPIO_Port  GPIOA

#define M_FR_IN1_Pin        GPIO_PIN_7
#define M_FR_IN1_GPIO_Port  GPIOA
#define M_FR_IN2_Pin        GPIO_PIN_8
#define M_FR_IN2_GPIO_Port  GPIOA

#define M_BL_IN1_Pin        GPIO_PIN_7    /* PB7 — PB6 now used for TIM4 PWM */
#define M_BL_IN1_GPIO_Port  GPIOB
#define M_BL_IN2_Pin        GPIO_PIN_12
#define M_BL_IN2_GPIO_Port  GPIOB

#define M_BR_IN1_Pin        GPIO_PIN_0
#define M_BR_IN1_GPIO_Port  GPIOB
#define M_BR_IN2_Pin        GPIO_PIN_1
#define M_BR_IN2_GPIO_Port  GPIOB

/* ── Ultrasonic sensors (HC-SR04, facing DOWN for edge detection) ────────────
   TRIG = output from STM32 (3.3 V is fine for HC-SR04)
   ECHO = input to STM32 via 10k+10k voltage divider (5 V → 2.5 V)          */
#define US_FRONT_TRIG_Pin        GPIO_PIN_9
#define US_FRONT_TRIG_GPIO_Port  GPIOA
#define US_FRONT_ECHO_Pin        GPIO_PIN_0
#define US_FRONT_ECHO_GPIO_Port  GPIOC

#define US_BACK_TRIG_Pin         GPIO_PIN_13
#define US_BACK_TRIG_GPIO_Port   GPIOB
#define US_BACK_ECHO_Pin         GPIO_PIN_14
#define US_BACK_ECHO_GPIO_Port   GPIOB


/* ── HIB03 RF receiver (via 10k+10k voltage divider) ────────────────────────
   OUT1 → START (PC5),  OUT2 → STOP (PC6)                                    */
#define HIB03_START_Pin          GPIO_PIN_5
#define HIB03_START_GPIO_Port    GPIOC
#define HIB03_STOP_Pin           GPIO_PIN_6
#define HIB03_STOP_GPIO_Port     GPIOC

/* ── Function prototypes ─────────────────────────────────────────────────── */
void Error_Handler(void);

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
