/*
 * behavior.h
 */
#ifndef INC_BEHAVIOR_H_
#define INC_BEHAVIOR_H_

#include <stdint.h>

typedef enum {
    BEHAVIOR_STOPPED = 0,
    BEHAVIOR_STARTUP,
    BEHAVIOR_SEARCH,
    BEHAVIOR_ATTACK,
    BEHAVIOR_EDGE_ESCAPE
} BehaviorState;

void Behavior_Start(void);
void Behavior_Stop(void);
void Behavior_Tick(void);

#endif
