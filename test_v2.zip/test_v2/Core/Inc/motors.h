/*
 * motors.h
 */
#ifndef INC_MOTORS_H_
#define INC_MOTORS_H_

#include "main.h"
#include <stdint.h>

typedef enum {
    MOTOR_FL = 0,
    MOTOR_FR,
    MOTOR_BL,
    MOTOR_BR
} MotorId;

void Motors_Init(void);
void Motors_SetSpeed(MotorId id, int8_t speed_percent);
void Motors_Drive(int8_t linear_percent, int8_t turn_percent);
void Motors_Stop(void);

#endif
